-----------------------------------------------
   Treasure Boat Adventure - ver1.5
-----------------------------------------------

It is a game in which you operate a sailing ship.
Pointing up by catching treasure shells etc.


[Game Start]
Open "treasure_boat_adv_start_en.htm" by Chrome browser


[OS environment]
64 bit Windows10 
32 bit Windows7

[Necessary software]
Google Chrome

---------------------------
      Game Operation
---------------------------

1) Control the boat with buttons under the panel.
  (N:STOP, R:BACK）

2) Wind direction arrow changes and move the boat way.
     
3) @ button throws a beit, if points remain.
   
4) Point increases in the time to catch the treasure shell and
   sailing in the circle region.


------------------------------
          Freesoft
------------------------------

Treasure Boat Adventure - ver1.5 is
free software.
(under the rule of GPL3.0 License)

>> Let's ask me for bugs & opinions.

------------------------------
           History
------------------------------

2017.6   Ver1.0 Orca,CTRL
2018.6   Ver1.1 Frame,Wind,BGM
2018.9   ver1.2 Squid
2021.9   ver1.3 boat wake
2022.6   ver1.4 2stage unified frame
2023.2   ver1.5 Sea snake


------------------------------
         Open Source
------------------------------

Source is public in GitHub, please use it.
Please tell me making the game in succession.

https://github.com/tmlbworks2020/Treasure-Boat-Adventure-v1.5
------------------------------
           Copyright
------------------------------

All right reserved 2023.2 (C) tmlb_soft

E-mail: tmlb_wks00@yahoo.co.jp

HomePage: http://www7b.biglobe.ne.jp/~tmlbworks/program/soft/soft-110.htm