//Tresure_Boat_Adv v1.5 (c) tmlb-works 2023.2
window.addEventListener("load",loadFunc,false);
setInterval(playerMove,250);
let ship_th=1.6;
let hdl_th=0;
let mvx=400;
let mvy=300;
let mvx1=400;
let mvy1=300;
let v_sp=0;
let torp=new Array(5);
torp[0]=new Array(5);
torp[1]=new Array(5);
torp[2]=new Array(5);
const rnd=Math.random();
let mvx2=400+300*Math.cos(rnd*6.3);
let mvy2=300+300*Math.sin(rnd*6.3);
let ss= new Array(2);
ss[0]=new Array(7);
ss[1]=new Array(7);
var see=0;
var vx__=0;
var vy__=0;
let fd=0;
let ar_ndx=new Array(200);
let ar_ndy=new Array(200);
var score=80;
var time_r=0;
var gm_e=0;
var pondx=new Array(5);
var pondy=new Array(5);
var pondr=new Array(5);
var swx=new Array(10);
var swy=new Array(10);
var mvx_ct2=400;
var mvy_ct2=300;
var move_r2=0;
var itemx=0;
var itemy=0;
var fishstop=0;
var itemx0=0;
var itemy0=0;
var sec_s=-1;
var ddr=0;
var dx_=0;
var dy_=0;
var timed=0;
let sp_dr=0;
var v_wx=0;
var v_wy=0;
var d_w=0;
let lv_flg=1;
let hd_flg=2;
//pond
let pornd=Math.round(16*Math.random());
pornd-=8;
pondx[0]=mvx+400+600*(Math.random()-0.5);
pondy[0]=mvy+250+300*(Math.random()-0.5);
pondr[0]=80;
pondx[1]=mvx+400+600*(Math.random()-0.5);
pondy[1]=mvy+250+300*(Math.random()-0.5);
pondr[1]=64;
//isle
for(let i=2;i<5;i++){
pondx[i]=mvx+400+Math.cos(i*Math.random())*(360+10*Math.random());
let isly=Math.random();
if(isly<0.3){isly-=1;}
pondy[i]=mvy+250+isly*(360+10*Math.random());
pondr[i]=20+60*Math.random();
}
function playerMove(){
var canvas=document.getElementById("stage1");
var ctx=canvas.getContext("2d");
var elm=document.getElementById('target');
var sec=new Date().getSeconds();

if(sec%1==0){
ctx.beginPath();
ctx.rect(0,0,850,650);
ctx.fillStyle='#30f';
ctx.fill();
ctx.closePath();
let cx=800-mvx;
let cy=600-mvy;
let score_r=Math.pow((mvx-cx),2)+Math.pow((cy-mvy),2);

if(score_r<144400){
score++;
time_r++;
if(score<0)score=0;
}

ctx.beginPath();
ctx.arc(800-mvx,600-mvy,380,0,12.6,false);
ctx.fillStyle='#396';
ctx.fill();
ctx.closePath();

for(let i=0;i<2;i++){
ctx.beginPath();
ctx.arc(pondx[i]-mvx,pondy[i]-mvy,pondr[i],0,12.6,false);
ctx.fillStyle='#cfc';
ctx.fill();
ctx.closePath();
}

for(let i=2;i<5;i++){
ctx.beginPath();
ctx.arc(pondx[i]-mvx,pondy[i]-mvy,pondr[i],0,12.6,false);
ctx.fillStyle='#060';
ctx.fill();
ctx.closePath();
ctx.beginPath();
ctx.arc(pondx[i]-mvx+pornd,pondy[i]-mvy,pondr[i]-8,0,12.6,false);
ctx.fillStyle='#fc6';
ctx.fill();
ctx.closePath();
ctx.beginPath();
ctx.arc(pondx[i]-mvx+pornd,pondy[i]-mvy+pornd,pondr[i]-16,0,12.6,false);
ctx.fillStyle='#09c';
ctx.fill();
ctx.closePath();
}

ctx.fillStyle='#efe';
ctx.font="20px 'Arial'";
//End
if(score<=0){gm_e=2;}else if(score>=1000){gm_e=1;}
if(gm_e==0){ 
ctx.fillText(" "+score,180,570,100);
}else if(gm_e==1){
ctx.beginPath();
var img= new Image();
img.src= "./pic/clear3.gif";
ctx.drawImage(img,200,200);
ctx.closePath();
}else if(gm_e==2){
ctx.beginPath();
var img = new Image();
img.src = "./pic/over3.gif";
ctx.drawImage(img,200,200);
ctx.closePath();
}
//Wind
ctx.beginPath();
ctx.arc(290,580,24,0,12.6,false);
ctx.fillStyle='#960';
ctx.fill();
ctx.closePath();

ctx.fillStyle='#efe';
ctx.font="30px 'Arial'";
if(d_w==0){ctx.fillText("��",282,560,100);}
else if(d_w==1){ctx.fillText("��",282,560,100);}
else if(d_w==2){ctx.fillText("��",282,560,100);}
else if(d_w==3){ctx.fillText("��",282,560,100);}
else if(d_w==4){ctx.fillText("��",282,560,100);}
//ITEM
if(catchchk(itemx-mvx,itemy-mvy,16)==1 && see==1){see=0;score+=250;}
if(score>10 && score%100==0){
if(sec_s==-1){
itemx0=mvx+400;
itemy0=mvy+300;
}else if(sec_s==0){
itemx0=itemx;
itemy0=itemy;
}
sec_s=1;
timed=0;
itemx=mvx+400+Math.cos(Math.random()*6.3)*(150+150*(Math.random()-0.5));
itemy=mvy+300+Math.sin(Math.random()*6.3)*(150+150*(Math.random()-0.5));
see=1;
}
if(see==1){
ctx.beginPath();
ctx.arc(itemx-mvx,itemy-mvy,10,0,12.6,false);
ctx.fillStyle='#f60';
ctx.fill();
ctx.closePath();
ctx.beginPath();
ctx.arc(itemx-mvx,itemy-mvy+5,5,0,12.6,false);
ctx.fillStyle='#ff3';
ctx.fill();
ctx.closePath();
}
//fvr
for(let i=0;i<=fd;i++){
if(catchchk2(ar_ndx[i],ar_ndy[i],20)==1){
ar_ndx[i]=-1000;
ar_ndy[i]=-1000;
fishstop=1;
}
}

if(hd_flg==0){if(hdl_th<-0.075){hdl_th-=0.015;}else{hdl_th=-0.075;}}
else if(hd_flg==1){if(hdl_th<-0.075){hdl_th-=0.007;}else{hdl_th=-0.075;}}
else if(hd_flg==2){if(hdl_th<-0.075){hdl_th=0;}else{hdl_th=0;}}
else if(hd_flg==3){if(hdl_th<0.075){hdl_th+=0.007;}else{hdl_th=0.075;}}
else if(hd_flg==4){if(hdl_th<0.075){hdl_th+=0.015;}else{hdl_th=0.075;}}

ship_th+=hdl_th;
let rectx_b=30*Math.cos(ship_th);
let recty_b=30*Math.sin(ship_th);
let rectx_d=-10*Math.sin(ship_th);
let recty_d=10*Math.cos(ship_th);
let rectx_c=rectx_d+rectx_b;
let recty_c=recty_d+recty_b;

ctx.beginPath();
ctx.moveTo(mvx,mvy);
ctx.lineTo(mvx+rectx_b,mvy+recty_b);
ctx.moveTo(mvx+rectx_b,mvy+recty_b);
ctx.lineTo(mvx+rectx_c,mvy+recty_c);
ctx.moveTo(mvx+rectx_c,mvy+recty_c);
ctx.lineTo(mvx+rectx_d,mvy+recty_d);
ctx.moveTo(mvx+rectx_d,mvy+recty_d);
ctx.lineTo(mvx,mvy);
ctx.lineWidth = 1;
ctx.stroke();

ctx.fillStyle ='#f93';
ctx.closePath();
const mvx_lt=mvx+rectx_b;
const mvy_lt=mvy+recty_b;

ctx.beginPath();
ctx.arc (mvx_lt,mvy_lt,3,0,12.6,false);
ctx.fillStyle='#fcc';
ctx.fill();
ctx.closePath();
//fire
const mvx_ct2p=(rectx_b+rectx_c+rectx_d)/4;
var mvx_ct1=mvx+(rectx_d+mvx_ct2p)/3;
mvx_ct2=mvx+mvx_ct2p;//GLB
var mvx_ct3=mvx+(rectx_b+rectx_c+mvx_ct2p)/3;

const mvy_ct2p=(recty_b+recty_c+recty_d)/4;
var mvy_ct1=mvy+(recty_d+mvy_ct2p)/3;
mvy_ct2=mvy+mvy_ct2p;
var mvy_ct3=mvy+(recty_b+recty_c+mvy_ct2p)/3;

ctx.beginPath();
ctx.arc(mvx_ct1,mvy_ct1,5,0,12.6,false);
ctx.arc(mvx_ct2,mvy_ct2,6,0,12.6,false);
ctx.arc(mvx_ct3,mvy_ct3,5,0,12.6,false);
ctx.fillStyle='#960';
ctx.fill();
ctx.closePath();

//mast
if(d_w==0){
const msx1=mvx+rectx_b/2;
const msy1=mvy+recty_b/2;
const msx2=mvx+(rectx_c+rectx_d)/2;
const msy2=mvy+(recty_c+recty_d)/2;

ctx.beginPath();
ctx.moveTo(msx1,msy1);
ctx.lineTo(msx2,msy2);
ctx.strokeStyle='#fff';
ctx.lineWidth=1;
ctx.stroke();

ctx.arc(mvx_ct2-12,mvy_ct2-6,16,0,1.5,false);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();
}else if(d_w==1){
ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,8,0,3,true);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();
}else if(d_w==2){
ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,8,1.5,4.5,true);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();
}else if(d_w==3){
ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,8,3,6,true);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();
}else if(d_w==4){
ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,8,1.5,4.5,false);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();
}

let hit_flag= new Array(3);

for(let i=0; i<3;i++){
hit_flag[i]=0;
hit_flag[i]=catchchk(torp[i][1],torp[i][2],10);
if(hit_flag[i]==1){score-=25;}
}

if(hit_flag[0]==1){
ctx.beginPath();
ctx.arc(mvx_ct1,mvy_ct1,6,0,6.3,false);
ctx.fillStyle='#d22';
ctx.fill();
ctx.closePath();
}

if(hit_flag[1]==1){
ctx.beginPath();
ctx.arc (mvx_ct2,mvy_ct2,6,0,6.3,false);
ctx.fillStyle='#d22';
ctx.fill();
ctx.closePath();
}

if(hit_flag[2]==1){
ctx.beginPath();
ctx.arc(mvx_ct3,mvy_ct3,6,0,6.3,false);
ctx.fillStyle='#d22';
ctx.fill();
ctx.closePath();
}

for(let i=3;i>=0;i--){
swx[i+1]=swx[i];
swy[i+1]=swy[i];
}
for(let i=8;i>=5;i--){
swx[i+1]=swx[i];
swy[i+1]=swy[i];
}

swx[0]=mvx;
swy[0]=mvy;
swx[1]=mvx+rectx_b;
swy[1]=mvy+recty_b;
swx[5]=mvx+rectx_d;
swy[5]=mvy+recty_d;
swx[6]=mvx+rectx_c;
swy[6]=mvy+recty_c;
for(let i=0;i<4;i++){
ctx.beginPath();
ctx.moveTo(swx[i],swy[i]);
ctx.lineTo(swx[i+1],swy[i+1]);
ctx.moveTo(swx[i+5],swy[i+5]);
ctx.lineTo(swx[i+6],swy[i+6]);
ctx.strokeStyle='#fff';
ctx.lineWidth=1;
ctx.stroke();
ctx.closePath(); 
}

if(sec%30==0){
const f=Math.random();
if(f<0.4){d_w=0;v_wx=0;v_wy=0;}
else if(f<0.55){d_w=1;v_wx=0;v_wy=0.8;}
else if(f<0.7){d_w=2;v_wx=-0.8;v_wy=0;}
else if(f<0.85){d_w=3;v_wx=0;v_wy=-0.8;}
else if(f<1){d_w=4;v_wx=0.8;v_wy=0;}
}

const w0=islechk2(mvx,mvy);
if(w0==0){
mvx-=v_sp*Math.cos(ship_th)+v_wx;
mvy-=v_sp*Math.sin(ship_th)+v_wy;
}else{
mvx+=v_sp*Math.cos(ship_th)+v_wx;
mvy+=v_sp*Math.sin(ship_th)+v_wy;
}

for(let i=0;i<=10;i++){
ctx.beginPath();
ctx.arc(ar_ndx[i]-(mvx_ct3-ar_ndx[i]),ar_ndy[i]-(mvy_ct3-ar_ndy[i]),3,0,6.3,false);
ctx.rect(ar_ndx[i]-(mvx_ct3-ar_ndx[i]),ar_ndy[i]-(mvy_ct3-ar_ndy[i]),1,8,6.3,false);
ctx.fillStyle='#f66';
ctx.fill();
ctx.closePath();
}

let ct=0;
for(let j=0;j<7;j++){
if(catchchk(ss[0][j],ss[1][j],15)==1){score-=5;ct=1;}
}

if(ct==1){
ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,7,0,12.6,false);
ctx.fillStyle='#aaa';
ctx.fill();
ctx.closePath();

ctx.beginPath();
ctx.arc(mvx_ct2,mvy_ct2,6,0,12.6,false);
ctx.fillStyle='#d22';
ctx.fill();
ctx.closePath();
}

if(see==1){
if(sec_s==1){
ddr=(Math.abs(itemx-mvx2-mvx)+Math.abs(itemy-mvy2-mvy));
if(ddr<40)sec_s=0;
if(timed<40)timed++;
dx_=itemx0-mvx+(itemx-itemx0)*timed/40;
dy_=itemy0-mvy+(itemy-itemy0)*timed/40;
}else{
const th_=sec%16;
const rx=(56-th_)*Math.cos(th_*3.14/12);
const ry=(56-th_)*Math.sin(th_*3.14/12);
dx_=itemx+(rx-mvx);
dy_=itemy+(ry-mvy);
}
mvx2=dx_;
mvy2=dy_;
for(let j=7;j>0;j--){
ss[0][j]=ss[0][j-1];
ss[1][j]=ss[1][j-1];
}
ss[0][0]=mvx2;
ss[1][0]=mvy2;
if(see=1){
ctx.beginPath();
for(let a=0;a<7;a++){
ctx.moveTo(ss[0][a],ss[1][a]);
ctx.lineTo(ss[0][a+1],ss[1][a+1]);
}

ctx.strokeStyle='rgba(0,250,0,1)';
ctx.lineWidth=6;
ctx.stroke();
ctx.closePath();
ctx.beginPath();
ctx.arc(ss[0][0],ss[1][0],7,0,6.28,false);
ctx.arc(ss[0][6],ss[1][6],2,0,6.28,false);
ctx.fillStyle='#0f0';
ctx.fill();
ctx.closePath();
ctx.beginPath();
ctx.arc(ss[0][0]+2,ss[1][0],2,0,6.28,false);
ctx.fillStyle='#0cc';
ctx.fill();
ctx.closePath();
}
}

let dx=mvx-mvx1;
if(dx==0){divd=1;}else{divd=dx;}
if(Math.abs(mvx-mvx1)>7){dx=7*(mvx-mvx1)/Math.abs(divd);}
let dy=mvy-mvy1;
if(dy==0){divd=1;}else{divd=dy;}
if(Math.abs(mvy-mvy1)>7){dy=5*(mvy-mvy1)/Math.abs(divd);}

const a=0.7;
const b=0.2;
mvx1+=(dx*a+vx__*b)/2;
sp_dr=(dy*a+vy__*b)/2;
mvy1+=sp_dr;
}

ctx.beginPath();
ctx.rect(320,560,100,40);
ctx.fillStyle='#960';
ctx.fill();
ctx.closePath();
ctx.font ="18px 'Arial'";

if(lv_flg==0){
ctx.fillStyle='#f90';
ctx.fillText("R",325,570,20);
ctx.fillStyle='#fff';
ctx.fillText("N",350,570,20);
ctx.fillText("1",375,570,20);
ctx.fillText("2",400,570,20);
}else if(lv_flg==1){
ctx.fillStyle='#fff';
ctx.fillText("R",325,570,20);
ctx.fillStyle='#f90';
ctx.fillText("N",350,570,20);
ctx.fillStyle='#fff';
ctx.fillText("1",375,570,20);
ctx.fillText("2",400,570,20);
}else if(lv_flg==2){
ctx.fillStyle='#fff';
ctx.fillText("R",325,570,20);
ctx.fillText("N",350,570,20);
ctx.fillStyle='#f90';
ctx.fillText("1",375,570,20);
ctx.fillStyle='#fff';
ctx.fillText("2",400,570,20);
}else if(lv_flg==3){
ctx.fillStyle='#fff';
ctx.fillText("R",325,570,20);
ctx.fillText("N",350,570,20);
ctx.fillText("1",375,570,20);
ctx.fillStyle='#f90';
ctx.fillText("2",400,570,20);
}

ctx.beginPath();
ctx.rect(430,560,125,40);
ctx.fillStyle='#960';
ctx.fill();
ctx.closePath();
ctx.font="18px 'Arial'";

if(hd_flg==0){
ctx.fillStyle='#f90';
ctx.fillText("L",435,570,20);
ctx.fillStyle='#fff';
ctx.fillText("��",460,570,20);
ctx.fillText("��",485,570,20);
ctx.fillText("��",510,570,20);
ctx.fillText("R",535,570,20);
}else if(hd_flg==1){
ctx.fillStyle='#fff';
ctx.fillText("L",435,570,20);
ctx.fillStyle='#f90';
ctx.fillText("��",460,570,20);
ctx.fillStyle='#fff';
ctx.fillText("��",485,570,20);
ctx.fillText("��",510,570,20);
ctx.fillText("R",535,570,20);
}else if(hd_flg==2){
ctx.fillStyle='#fff';
ctx.fillText("L",435,570,20);
ctx.fillText("��",460,570,20);
ctx.fillStyle='#f90';
ctx.fillText("��",485,570,20);
ctx.fillStyle='#fff';
ctx.fillText("��",510,570,20);
ctx.fillText("R",535,570,20);
}else if(hd_flg==3){
ctx.fillStyle='#fff';
ctx.fillText("L",435,570,20);
ctx.fillText("��",460,570,20);
ctx.fillText("��",485,570,20);
ctx.fillStyle='#f90';
ctx.fillText("��",510,570,20);
ctx.fillStyle='#fff';
ctx.fillText("R",535,570,20);
}else if(hd_flg==4){
ctx.fillStyle='#fff';
ctx.fillText("L",435,570,20);
ctx.fillText("��",460,570,20);
ctx.fillText("��",485,570,20);
ctx.fillText("��",510,570,20);
ctx.fillStyle='#f90';
ctx.fillText("R",535,570,20);
}

ctx.beginPath();
ctx.rect(570,560,40,40);
ctx.fillStyle='#960';
ctx.fill();
ctx.closePath();
ctx.font="18px 'Arial'";
ctx.fillStyle='#fff';
ctx.fillText("@",580,570,20);

if(hdl_th>0){hdl_th-=0.01;}
else{hdl_th+=0.01}

let flag=time_r%100;
if(flag==30){
torp[0][1]=mvx_ct2+(40+30*(Math.random()-1));
torp[0][2]=mvy_ct2+(40+30*(Math.random()-1));
torp[0][3]=(torp[0][1]-mvx_ct2)/30;
torp[0][4]=(torp[0][2]-mvy_ct2)/30;
}else if(flag==60){
torp[1][1]=mvx_ct2+(40+40*(Math.random()-0.6));
torp[1][2]=mvy_ct2+(40+40*(Math.random()-0.6));
torp[1][3]=(torp[1][1]-mvx_ct2)/30;
torp[1][4]=(torp[1][2]-mvy_ct2)/30;
}else if(flag==90){
torp[2][1]=mvx_ct2+(40+40*(Math.random()-0.4));
torp[2][2]=mvy_ct2+(40+40*(Math.random()-0.4));
torp[2][3]=(torp[2][1]-mvx_ct2)/25;
torp[2][4]=(torp[2][2]-mvy_ct2)/25;
}

for(let i=0;i<3;i++){
if(islechk2(torp[i][1],torp[i][2])==0){
torp[i][1]-=torp[i][3];
torp[i][2]-=torp[i][4];
}else{
torp[i][1]+=torp[i][3];
torp[i][2]+=torp[i][4];
}
}

ctx.beginPath();
ctx.rect(torp[0][1],torp[0][2],10,2);
ctx.rect(torp[1][1],torp[1][2],10,2);
ctx.rect(torp[2][1],torp[2][2],10,2);
ctx.fillStyle='222';
ctx.fill();
ctx.closePath();
ctx.beginPath();
ctx.rect(torp[0][1],torp[0][2]+2,10,2);
ctx.rect(torp[1][1],torp[1][2]+2,10,2);
ctx.rect(torp[2][1],torp[2][2]+2,10,2);
ctx.fillStyle='#eee';
ctx.fill();
ctx.closePath();

canvas.onmousedown
=function(e){
var canvas=document.getElementById("stage1");
var ctx=canvas.getContext("2d");
mousedown=true;
}
canvas.onmousemove
= function(e){
if(mousedown){}}
canvas.onmouseup
=function(e){
mousedown=false;
clx=e.pageX;
cly=e.pageY;
ctx.font="18px 'Arial'";
if(cly>580 && cly<630){
if(clx>=345 && clx<=370){
v_sp=-0.5;	
lv_flg=0;
}else if(clx>370 && clx<=395){
v_sp=0;
lv_flg=1;
}else if(clx>395 && clx<=420){
v_sp=1;
lv_flg=2;
}else if(clx>420 && clx<=445){
v_sp=2;	
lv_flg=3;
}else if(clx>=455 && clx<=480){//handle
hd_flg=0;
}else if(clx>480 && clx<=505){
hd_flg=1;
}else if(clx>505 && clx<=530){
hd_flg=2;
}else if(clx>530 && clx<=555){
hd_flg=3;
}else if(clx>555 && clx<=580){
hd_flg=4;

}else if(clx>600 && clx<=635){
ctx.font="18px 'Arial'";
ctx.fillStyle='#f00';
ctx.fillText("@",580,570,20);
if(score>=10){
let fx = 0;
let fy = 0;
ar_ndx[fd]=mvx_ct2+(mvx_ct3-mvx_ct1)*(1+fx);
ar_ndy[fd]=mvy_ct2+(mvy_ct3-mvy_ct1)*(1+fy);
console.log(ar_ndx[fd],ar_ndy[fd]);
fd++;
if(fd==5){fd=0;}
score-=10;
}
}
}
}
}
function loadFunc(){
var canvas=document.getElementById("stage1");
var ctx=canvas.getContext("2d");
ctx.fillStyle="blue";
ctx.font="20px 'Arial'";
ctx.textAlign="left";
ctx.textBaseline="top";
ctx.fillText("Tresure WindBoat ver1.5 ",10,10,150);
}
function waterchk(m,n){
var r=0;
for(let i=0;i<2;i++){
let r=Math.sqrt(Math.pow(m-(pondx[i]-mvx),2)+Math.pow(n-(pondy[i]-mvy),2));
if(r<pondr[i])return 1;
}
return 0;
}
function islechk(m,n){
var r=0;
for(let i=2;i<5;i++){
r=Math.sqrt(Math.pow(m-pondx[i],2)+Math.pow(n-pondy[i],2));
if(r<pondr[i])return 1;
}
return 0;
}
function islechk2(m,n){
var r=0;
for(let i=2;i<5;i++){
r=Math.sqrt(Math.pow(m-(pondx[i]-mvx),2)+Math.pow(n-(pondy[i]-mvy),2));
if(r<pondr[i])return 1;
}
return 0;
}
function catchchk(x,y,ra){
let r=Math.pow(x-mvx_ct2,2)+Math.pow(y-mvy_ct2,2);
if(r<ra*ra)return 1;
return 0;
}
function catchchk2(x,y,ra){
let r=Math.pow(x-mvx2,2)+Math.pow(y-mvy2,2);
if(r<ra*ra)return 1;
return 0;
}
function mashrchk(x,y){
var r=0;
for(let i=0;i<=fd;i++){
r=Math.pow(x-ar_ndx[i],2)+Math.pow(y-ar_ndy[i],2);
if(r<9){return 1;}
}
return 0;
}
